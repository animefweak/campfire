
=> **Disclaimer**

This android application is Open Source project and it gives general layout for chat based application like Whatsapp but not related to Whatsapp or Facebook.

=> **Features**

1. Contacts fetching
2. Contacts display
3. Chat layout
4. Collapsing Toolbar for contacts image view
5. Image view in dialog box

![]({{site.baseurl}}/https://github.com/Lokeshm24/Whatsapp_Android_App/blob/master/app/src/main/assets/Chat_Screen.png)
![]({{site.baseurl}}/https://github.com/Lokeshm24/Whatsapp_Android_App/blob/master/app/src/main/assets/View_Profile.png)
